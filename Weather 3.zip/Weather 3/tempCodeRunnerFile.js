require("dotenv").config();

const express = require("express");
const cors = require("cors");
const axios = require("axios");

const app = express();

const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.get("/", (req,res)=>{

    res.json({
        message:"SkyCast Pro API Running 🚀"
    });
});

/* WEATHER */

app.get("/weather/:city", async(req,res)=>{

    try{

        const response = await axios.get(

            `https://api.openweathermap.org/data/2.5/weather?q=${req.params.city}&appid=${process.env.API_KEY}&units=metric`
        );

        res.json(response.data);

    }catch(error){

        res.status(404).json({
            message:"City not found"
        });
    }
});

/* LOCATION */

app.get("/weather-location/:lat/:lon", async(req,res)=>{

    try{

        const response = await axios.get(

            `https://api.openweathermap.org/data/2.5/weather?lat=${req.params.lat}&lon=${req.params.lon}&appid=${process.env.API_KEY}&units=metric`
        );

        res.json(response.data);

    }catch(error){

        res.status(500).json({
            message:"Location weather failed"
        });
    }
});

/* FORECAST */

app.get("/forecast/:city", async(req,res)=>{

    try{

        const response = await axios.get(

            `https://api.openweathermap.org/data/2.5/forecast?q=${req.params.city}&appid=${process.env.API_KEY}&units=metric`
        );

        res.json(response.data);

    }catch(error){

        res.status(500).json({
            message:"Forecast failed"
        });
    }
});

/* AQI */

app.get("/air-quality/:lat/:lon", async(req,res)=>{

    try{

        const response = await axios.get(

            `https://api.openweathermap.org/data/2.5/air_pollution?lat=${req.params.lat}&lon=${req.params.lon}&appid=${process.env.API_KEY}`
        );

        res.json({
            air:response.data
        });

    }catch(error){

        res.status(500).json({
            message:"AQI failed"
        });
    }
});

app.listen(PORT,()=>{

    console.log(`🚀 Server running on port ${PORT}`);
});